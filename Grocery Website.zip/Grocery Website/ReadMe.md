# python_projects_grocery_webapp
In this python project, I built a grocery store management application. It is a 3 tier application,
1. Front end: UI is written in HTML/CSS/Javascript/Bootstrap
2. Backend: Python and Flask
3. Database: mysql

